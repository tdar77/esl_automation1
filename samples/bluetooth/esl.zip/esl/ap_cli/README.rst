.. zephyr:code-sample:: bt_esl_ap_cli
   :name: Bluetooth LE Electronic Shelf Label (ESL) Access Point CLI
   :relevant-api: bt_gap bluetooth bt_gatt

   Demonstrate Bluetooth LE Electronic Shelf Label Access Point functionality with CLI interface.

Overview
********

This sample demonstrates the Bluetooth LE Electronic Shelf Label (ESL) Access Point
functionality with a command-line interface for managing ESL tags in a retail environment.

The Access Point uses Periodic Advertising with Responses (PAwR) to communicate with
multiple ESL tags simultaneously. It can discover, connect to, and manage various
ESL tag operations including display updates, LED control, and sensor information
retrieval.

Features
========

* **ESL Access Point Role**: Acts as central controller for ESL tags
* **Periodic Advertising with Responses (PAwR)**: Efficient communication with multiple tags
* **GATT Client Operations**: Service discovery and characteristic access
* **CLI Interface**: Interactive shell commands for testing and demonstration
* **Multi-tag Management**: Diagnostic profiles provision one group of four tags
* **Tag Operations**: Display updates, LED control, sensor data collection
* **Encrypted Advertising**: Support for secure ESL communications

CLI Commands
============

The sample provides the following shell commands under the ``esl_ap`` namespace:

* ``bt_on`` - Initialize Bluetooth stack
* ``start_scan`` - Start scanning for ESL tags
* ``stop_scan`` - Stop scanning operation
* ``auto [count]`` - Sync 1-1000 additional tags within configured capacity, retaining previously synced tags
* ``auto_stop`` - Finish the current tag attempt, then stop without removing successful tags
* ``discover <Grp ID> <ESL ID>`` - Discover ESL services on a specific tag
* ``start_padv`` - Start periodic advertising
* ``stop_padv`` - Stop periodic advertising
* ``connect <Grp ID> <ESL ID>`` - Connect to an ESL tag
* ``disconnect <Grp ID> <ESL ID>`` - Disconnect from an ESL tag
* ``led_control <Grp ID> <ESL ID> <led_index> <clr brightness> <flsh pattern> <rpt type> [delay in s]`` - Control tag LED
* ``display_update <Grp ID> <ESL ID> <display_index> <image index> [delay in s]`` - Update tag display
* ``sensor_info <Grp ID> <ESL ID>`` - Read sensor information from tag

Repeated automation runs continue assigning ESL IDs within the current AP boot.
For example, ``esl_ap auto 3`` assigns addresses ``0:0`` through ``0:2``; after
it finishes, ``esl_ap auto 1`` assigns ``0:3``. The current diagnostic profiles
stop at four tags. With a compatible library and larger tables, the allocator
advances through ``0:15``, then ``1:0`` through ``1:15``, and so on.
These addresses are shown in decimal.
The CLI address arguments for manual commands use hexadecimal.

Only a failed connect/discover/configure/sync attempt is automatically removed.
Its address is reused on the next run; successfully synced tags are retained.
If removal fails, a new run retries cleanup before reusing the address.
``auto_stop`` lets an in-flight attempt finish, so its final result is recorded.
A new run is rejected as busy until that attempt completes or fails.

With no count, automation uses ``CONFIG_ESL_AP_AUTO_SYNC_COUNT``. Counts and
allocation tracking are 16-bit. A batch that exceeds the remaining configured
group capacity is rejected before scanning. The sample profiles have been
reverted to one group of four tags and four pairing slots to isolate the
initialization failure with the bundled prebuilt ESL core library. Automation
accepts this reduced single-group capacity and preserves successfully synced
tags across runs.

The original PAwR timing is also restored: periodic interval min/max 543.75 ms,
two subevents, subevent interval 260 ms, response slot delay 150 ms, response
slot spacing 4 ms, and ten response slots per subevent.

For the eventual 1000-tag target, the planned 63-subevent PAwR schedule provides 63
groups of 16 addresses (1008 total); the 1000th tag is ``62:7``. Keep
``CONFIG_BT_ESL_MAX_ESL_TAGS_SUPPORTED=16`` and increase
``CONFIG_BT_ESL_MAX_GROUPS_SUPPORTED`` as capacity grows, and restore the
63-subevent schedule. This requires a compatible rebuilt ESL core library;
the bundled prebuilt library rejects the two-group, 16-tag configuration.
Bond storage must
cover all retained tags across groups, even after their GATT connections have
disconnected. This tree currently caps ``CONFIG_BT_MAX_PAIRED`` at 128, so
1000 retained bonds still require a stack/storage change and memory validation
on the target hardware. ``CONFIG_BT_MAX_CONN`` only limits simultaneous
connections. Tags and the allocation cursor are not persisted across AP reboot.

To check the diagnostic baseline, initialize the AP and verify that it no
longer reports ``0xFFFF``. Complete ``auto 3`` and ``auto 1``; all four entries
should remain visible in ``esl_dev_list``, and another ``auto 1`` should be
rejected as full. Group rollover testing requires a compatible library and
larger tables. Also
check a failed attempt and a stop during provisioning: failure should remove
only the failing tag, while stop should retain the tag if its attempt succeeds.

Requirements
************

* A board with Bluetooth LE support
* A controller that supports:

  - Extended Advertising
  - Periodic Advertising with Responses (PAwR)
  - Encrypted Advertising Data (EAD)
  - Multiple connections (up to 5)

* One or more ESL tags (use the corresponding :zephyr:code-sample:`bt_esl_tag_cli` sample)

Building and Running
********************

This sample can be found under :file:`esl/platforms/nrf52/zephyr/ap_cli` in the
ESL source tree.

Build the sample:

.. zephyr-app-commands::
   :zephyr-app: esl/platforms/nrf52/zephyr/ap_cli
   :board: nrf52840dk_nrf52840
   :goals: build flash
   :compact:

Use with the corresponding :zephyr:code-sample:`bt_esl_tag_cli` sample that will
act as ESL tags responding to this Access Point.

Sample Output
=============

When the application starts, you will see output similar to:

.. code-block:: console

   *** Booting Zephyr OS build zephyr-v3.4.0 ***
   [00:00:04.510,223] <inf> bt_hci_core: HW Variant: nRF52x (0x0002)
   [00:00:04.510,253] <inf> bt_hci_core: Firmware: Standard Bluetooth controller (0x00) Version 137.20634 Build 2617349514
   [00:00:04.511,016] <inf> bt_hci_core: Identity: E5:B8:0C:D8:1F:FD (random)
   [00:00:04.511,047] <inf> bt_hci_core: HCI: version 6.0 (0x0e) revision 0x10f3, manufacturer 0x0059
   [00:00:04.511,077] <inf> bt_hci_core: LMP: version 6.0 (0x0e) subver 0x10f3
   [ESL PL]: Bluetooth initialized
   [ESL PL]: Local BD address E5:B8:0C:D8:1F:FD (random)
   [ESL PL]: Settings loaded successfully
   [ESL PL]: Auth info callbacks registered successfully
   [ESL PL]: ESL PL is initialized
   [APPL]: ESL PL initialized successfully
   ESL Module Version 001:000:000
   ==========================================
   uart:~$ esl_ap start_scan
   ESLP: Started Scanning
   [ESL PL]: Scanning successfully started
   uart:~$ esl_ap add_esl 1 E5B80CD81FFD 0 0
   Adding ESL device
   uart:~$

Testing
=======

1. Build and flash the Access Point CLI sample to one board
2. Build and flash the Tag CLI sample to one or more other boards
3. Use the CLI commands to:

   a. Initialize Bluetooth: ``esl_ap bt_on``
   b. Start scanning: ``esl_ap start_scan``
   c. Start periodic advertising: ``esl_ap start_padv``
   d. Connect to discovered tags and configure them
   e. Control tag displays and LEDs
   f. Read sensor data from tags

References
==========

* `Bluetooth SIG Electronic Shelf Label Service Specification <https://www.bluetooth.com/specifications/specs/electronic-shelf-label-service-1-0/>`_
* `Bluetooth SIG Electronic Shelf Label Profile Specification <https://www.bluetooth.com/specifications/specs/electronic-shelf-label-profile-1-0/>`_
* `Bluetooth samples <https://docs.zephyrproject.org/latest/samples/bluetooth/bluetooth.html>`_ for more Bluetooth LE examples
